<?php
    ini_set('date.timezone', 'America/Argentina/Buenos_Aires');    
?>