<?php
interface iVista{
    public function setVariables(array $arrayVariables); 
    public function renderizar();
}
?>