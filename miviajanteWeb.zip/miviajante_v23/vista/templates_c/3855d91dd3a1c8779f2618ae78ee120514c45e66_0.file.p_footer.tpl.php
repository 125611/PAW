<?php
/* Smarty version 3.1.30, created on 2017-08-22 21:35:53
  from "C:\Develop\AppServ\www\PAW\miviajante_v23\vista\templates\p_footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_599ccde9ad2509_06871821',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3855d91dd3a1c8779f2618ae78ee120514c45e66' => 
    array (
      0 => 'C:\\Develop\\AppServ\\www\\PAW\\miviajante_v23\\vista\\templates\\p_footer.tpl',
      1 => 1503448440,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_599ccde9ad2509_06871821 (Smarty_Internal_Template $_smarty_tpl) {
?>
<footer> 
       
</footer><?php }
}
