<?php
/* Smarty version 3.1.30, created on 2017-07-16 15:10:42
  from "C:\xampp\htdocs\PAW\miviajante_v20\vista\templates\vacio.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_596bac22a1e3a6_55197568',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '06a1de21ed6c204ae53c0d1c0b944d63503ff67b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PAW\\miviajante_v20\\vista\\templates\\vacio.tpl',
      1 => 1500228363,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_596bac22a1e3a6_55197568 (Smarty_Internal_Template $_smarty_tpl) {
}
}
