<?php
/* Smarty version 3.1.30, created on 2017-07-17 09:17:32
  from "C:\xampp\htdocs\PAW\miviajante_v21\vista\templates\vacio.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_596caadc159395_35913043',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '99ee84cb124d671224347deba6b4026a8d90d7bb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PAW\\miviajante_v21\\vista\\templates\\vacio.tpl',
      1 => 1500228363,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_596caadc159395_35913043 (Smarty_Internal_Template $_smarty_tpl) {
}
}
