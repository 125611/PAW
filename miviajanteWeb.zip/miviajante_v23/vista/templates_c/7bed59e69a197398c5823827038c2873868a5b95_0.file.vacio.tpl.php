<?php
/* Smarty version 3.1.30, created on 2017-08-19 10:06:02
  from "C:\Develop\AppServ\www\PAW\miviajante_v22\vista\templates\vacio.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_599837ba50fb42_61470284',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7bed59e69a197398c5823827038c2873868a5b95' => 
    array (
      0 => 'C:\\Develop\\AppServ\\www\\PAW\\miviajante_v22\\vista\\templates\\vacio.tpl',
      1 => 1503012386,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_599837ba50fb42_61470284 (Smarty_Internal_Template $_smarty_tpl) {
}
}
