<?php
/* Smarty version 3.1.30, created on 2017-08-22 13:01:41
  from "C:\Develop\AppServ\www\PAW\miviajante_v23\vista\templates\vacio.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_599c55658ff843_75318372',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2932f5a6c8c17567bb370ef57101a15fefbfe612' => 
    array (
      0 => 'C:\\Develop\\AppServ\\www\\PAW\\miviajante_v23\\vista\\templates\\vacio.tpl',
      1 => 1503012386,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_599c55658ff843_75318372 (Smarty_Internal_Template $_smarty_tpl) {
}
}
