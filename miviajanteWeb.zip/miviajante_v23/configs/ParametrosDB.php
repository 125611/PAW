<?php
return array(
    "driver"    =>"mysql",
    "host"      =>"localhost",
    "user"      =>"root",
    "pass"      =>"root1234",
    "database"  =>"MiViajante",
    "charset"   =>"utf8"
);
